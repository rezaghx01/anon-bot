import sqlite3

def init_db():
    conn = sqlite3.connect("messages.db")
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS blocked_users (user_id INTEGER PRIMARY KEY)''')
    c.execute('''CREATE TABLE IF NOT EXISTS messages (user_id INTEGER, text TEXT)''')
    conn.commit()
    conn.close()

def is_blocked(user_id):
    conn = sqlite3.connect("messages.db")
    c = conn.cursor()
    c.execute("SELECT user_id FROM blocked_users WHERE user_id = ?", (user_id,))
    result = c.fetchone()
    conn.close()
    return result is not None

def block_user(user_id):
    conn = sqlite3.connect("messages.db")
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO blocked_users (user_id) VALUES (?)", (user_id,))
    conn.commit()
    conn.close()

def save_message(user_id, text):
    conn = sqlite3.connect("messages.db")
    c = conn.cursor()
    c.execute("INSERT INTO messages (user_id, text) VALUES (?, ?)", (user_id, text))
    conn.commit()
    conn.close()
